import { BaseForm } from './base.component';

describe('BaseForm', () => {
  it('should create an instance', () => {
    expect(new BaseForm()).toBeTruthy();
  });
});
