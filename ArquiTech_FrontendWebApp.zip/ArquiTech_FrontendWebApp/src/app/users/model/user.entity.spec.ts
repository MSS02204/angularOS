import { UserEntity } from './user.entity';

describe('UserEntity', () => {
  it('should create an instance', () => {
    expect(new UserEntity()).toBeTruthy();
  });
});
