import { MaterialEntity } from './material.entity';

describe('MaterialEntity', () => {
  it('should create an instance', () => {
    expect(new MaterialEntity()).toBeTruthy();
  });
});
