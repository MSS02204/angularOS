import { MachineryEntity } from './machinery.entity';

describe('MachineryEntity', () => {
  it('should create an instance', () => {
    expect(new MachineryEntity()).toBeTruthy();
  });
});
