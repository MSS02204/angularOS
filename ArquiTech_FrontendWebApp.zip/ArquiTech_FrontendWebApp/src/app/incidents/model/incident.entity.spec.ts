import { IncidentEntity } from './incident.entity';

describe('IncidentEntity', () => {
  it('should create an instance', () => {
    expect(new IncidentEntity()).toBeTruthy();
  });
});
