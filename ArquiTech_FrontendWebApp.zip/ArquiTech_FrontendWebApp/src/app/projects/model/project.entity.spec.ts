import { ProjectEntity } from './project.entity';

describe('ProjectEntity', () => {
  it('should create an instance', () => {
    expect(new ProjectEntity()).toBeTruthy();
  });
});
