import { WorkerEntity } from './worker.entity';

describe('WorkerEntity', () => {
  it('should create an instance', () => {
    expect(new WorkerEntity()).toBeTruthy();
  });
});
